﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConverterApp
// This program was written by Gail Mosdell edited by Kevin :)
// It forms the base of a converter program for the OS-Assessment Two for Cert IV
// Date : February 2017
{ 
    public partial class frm_Main : Form
    {
        public frm_Main()
        {
            InitializeComponent();
        }

        // Global Variables and Constants
        double dbl_UofM, dbl_Convert;
        public string[] results = new string[5];
        public int counter = 0;

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_CM_to_Inches_Click(object sender, EventArgs e)
        {
            const double CM_TO_INCH = 0.3937;

            // validate user entry and convert to a double
            if (counter < 5)
            {

                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear();
                    txt_UnitOfMeasure.Focus();
                    txt_Convert.Clear();
                    lbl_Convert.Text = "";
                    lbl_Display.Text = "";
                }
                else
                {
                    dbl_Convert = dbl_UofM * CM_TO_INCH;
                    txt_Convert.Text = dbl_Convert.ToString();
                    lbl_Display.Text = txt_UnitOfMeasure.Text + " centimetres is converted to ";
                    lbl_Convert.Text = " inches.";
                    results[counter] = lbl_Display.Text + txt_Convert.Text + lbl_Convert.Text;
                    counter++;
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 Conversions.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            const double CELCIUS_TO_FAHRENHEIT = 1.8;
            if (counter < 5)
            {
                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear();
                    txt_UnitOfMeasure.Focus();
                    txt_Convert.Clear();
                    lbl_Convert.Text = "";
                    lbl_Display.Text = "";
                }
                else
                {
                    dbl_Convert = dbl_UofM * CELCIUS_TO_FAHRENHEIT + 32;
                    txt_Convert.Text = dbl_Convert.ToString();
                    lbl_Display.Text = txt_UnitOfMeasure.Text + " Celcius is converted to ";
                    lbl_Convert.Text = " Fahrenheit.";
                    results[counter] = lbl_Display.Text + txt_Convert.Text + lbl_Convert.Text;
                    counter++;
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 Conversions.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            const double C_TO_FEET = 0.0328084;
            if (counter < 5)
            {
                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear();
                    txt_UnitOfMeasure.Focus();
                    txt_Convert.Clear();
                    lbl_Convert.Text = "";
                    lbl_Display.Text = "";
                }
                else
                {
                    dbl_Convert = dbl_UofM * C_TO_FEET;
                    txt_Convert.Text = dbl_Convert.ToString();
                    lbl_Display.Text = txt_UnitOfMeasure.Text + " Centimeters are converted to ";
                    lbl_Convert.Text = " Feet.";
                    results[counter] = lbl_Display.Text + txt_Convert.Text + lbl_Convert.Text;
                    counter++;
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 Conversions.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            const double K_TO_MILES = 0.621371;
            if (counter < 5)
            {
                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear();
                    txt_UnitOfMeasure.Focus();
                    txt_Convert.Clear();
                    lbl_Convert.Text = "";
                    lbl_Display.Text = "";
                }
                else
                {
                    dbl_Convert = dbl_UofM * K_TO_MILES;
                    txt_Convert.Text = dbl_Convert.ToString();
                    lbl_Display.Text = txt_UnitOfMeasure.Text + " Kilometer are converted to ";
                    lbl_Convert.Text = " Mile.";
                    results[counter] = lbl_Display.Text + txt_Convert.Text + lbl_Convert.Text;
                    counter++;
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 Conversions.");
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            for (int displaycounter = 0; displaycounter < 5; displaycounter++)
            {
                ResultList.AppendText(results[displaycounter] + Environment.NewLine);
            }
        }



        private void btn_M_to_Feet_Click(object sender, EventArgs e)
        {
            const double M_TO_FEET = 3.28084;

            // validate user entry and convert to a double
            if (counter < 5)
            {
                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear();
                    txt_UnitOfMeasure.Focus();
                    txt_Convert.Clear();
                    lbl_Convert.Text = "";
                    lbl_Display.Text = "";
                }
                else
                {
                    dbl_Convert = dbl_UofM * M_TO_FEET;
                    txt_Convert.Text = dbl_Convert.ToString();
                    lbl_Display.Text = txt_UnitOfMeasure.Text + " Meters are converted to ";
                    lbl_Convert.Text = " Feet.";
                    results[counter] = lbl_Display.Text + txt_Convert.Text + lbl_Convert.Text;
                    counter++;
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 Conversions.");
            }
        }


    }
}
